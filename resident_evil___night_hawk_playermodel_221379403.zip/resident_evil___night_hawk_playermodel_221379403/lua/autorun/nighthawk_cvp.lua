player_manager.AddValidModel( "NIGHT HAWK_cvp", 				"models/player/lordvipes/rerc_nighthawk/nighthawk_cvp.mdl" )

player_manager.AddValidHands( "NIGHT HAWK_cvp", "models/player/lordvipes/rerc_nighthawk/arms/nighthawkARMS_cvp.mdl", 0, "00000000" )

list.Set( "PlayerOptionsModel",  "NIGHT HAWK_cvp", 				"models/player/lordvipes/rerc_nighthawk/nighthawk_cvp.mdl" )
